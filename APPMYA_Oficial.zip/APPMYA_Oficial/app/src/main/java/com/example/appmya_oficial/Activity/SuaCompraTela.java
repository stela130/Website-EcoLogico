package com.example.appmya_oficial.Activity;

import android.app.Activity;

public class SuaCompraTela extends Activity {
}
