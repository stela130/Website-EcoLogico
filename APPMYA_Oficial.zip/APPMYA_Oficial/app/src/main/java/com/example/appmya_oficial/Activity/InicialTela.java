package com.example.appmya_oficial.Activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.appmya_oficial.R;

public class InicialTela extends AppCompatActivity {

    Dialog myDialog;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_inicial);

        Button btnCadastro;
        btnCadastro = findViewById(R.id.btnCadastro);

        btnCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(InicialTela.this, CadastroTela.class);
                startActivity(i);
            }
        });



    }


    public void MostrarLogin(View v) {
        ImageView imgFechar;
        Button btnLogin;
        myDialog.setContentView(R.layout.tela_login);
        imgFechar = (ImageView) myDialog.findViewById(R.id.imgFechar);
        btnLogin = (Button) myDialog.findViewById(R.id.btnLogin);

        imgFechar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }

}