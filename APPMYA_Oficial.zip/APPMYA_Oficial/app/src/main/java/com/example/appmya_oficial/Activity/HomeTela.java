package com.example.appmya_oficial.Activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.appmya_oficial.Adaptor.CategoryAdaptor;
import com.example.appmya_oficial.Adaptor.PromocaoAdaptor;
import com.example.appmya_oficial.Domain.CategoryDomain;
import com.example.appmya_oficial.Domain.PromocoesDomain;
import com.example.appmya_oficial.R;

import java.util.ArrayList;

public class HomeTela extends AppCompatActivity {
private RecyclerView.Adapter adapter, adapter2;
private RecyclerView recyclerViewCategoryList, recyclerViewPromocaoList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_home);

        recyclerViewCategory();
        recyclerViewPromocao();
    }

    private void recyclerViewCategory() {
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false);
        recyclerViewCategoryList=findViewById(R.id.recyclerViewC);
        recyclerViewCategoryList.setLayoutManager(linearLayoutManager);

        ArrayList<CategoryDomain> category=new ArrayList<>();
        category.add(new CategoryDomain("Produto1", "cat_1"));
        category.add(new CategoryDomain("Produto2", "cat_2"));
        category.add(new CategoryDomain("Produto3", "cat_3"));
        category.add(new CategoryDomain("Produto4", "cat_4"));
        category.add(new CategoryDomain("Produto5", "cat_5"));

        adapter=new CategoryAdaptor(category);
        recyclerViewCategoryList.setAdapter(adapter);
    }
    private void recyclerViewPromocao(){
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false);
        recyclerViewPromocaoList=findViewById(R.id.recyclerViewP);
        recyclerViewPromocaoList.setLayoutManager(linearLayoutManager);

        ArrayList<PromocoesDomain> promocoesList=new ArrayList<>();
        promocoesList.add(new PromocoesDomain("Produto1", "p1", "descricao bla bla bla", 10.00));
        promocoesList.add(new PromocoesDomain("Produto2", "p2", "descricao bla bla bla", 10.00));
        promocoesList.add(new PromocoesDomain("Produto3", "p3", "descricao bla bla bla", 10.00));
        promocoesList.add(new PromocoesDomain("Produto4", "p4", "descricao bla bla bla", 10.00));
        promocoesList.add(new PromocoesDomain("Produto5", "p5", "descricao bla bla bla", 10.00));

        adapter2=new PromocaoAdaptor(promocoesList);
        recyclerViewPromocaoList.setAdapter(adapter2);
    }

}
