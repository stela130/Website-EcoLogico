package com.example.appmya_oficial.Adaptor;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.appmya_oficial.Domain.CategoryDomain;
import com.example.appmya_oficial.R;

import java.util.ArrayList;

public class CategoryAdaptor extends RecyclerView.Adapter<CategoryAdaptor.ViewHolder> {
    ArrayList<CategoryDomain>categoriaDomains;

    public CategoryAdaptor(ArrayList<CategoryDomain> categoriaDomains) {
        this.categoriaDomains = categoriaDomains;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate= LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_categoria,parent, false);
        return new ViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.nomeCategoria.setText(categoriaDomains.get(position).getTitulo());
        String fotUrl="";
        switch (position){
            case 0:{
                fotUrl="cat_1";
                holder.mainLayout.setBackground(ContextCompat.getDrawable(holder.itemView.getContext(),R.drawable.background_categoria));
                break;
            }
            case 1:{
                fotUrl="cat_2";
                holder.mainLayout.setBackground(ContextCompat.getDrawable(holder.itemView.getContext(),R.drawable.background_categoria));
                break;
            }
            case 2:{
                fotUrl="cat_3";
                holder.mainLayout.setBackground(ContextCompat.getDrawable(holder.itemView.getContext(),R.drawable.background_categoria));
                break;
            }
            case 3:{
                fotUrl="cat_4";
                holder.mainLayout.setBackground(ContextCompat.getDrawable(holder.itemView.getContext(),R.drawable.background_categoria));
                break;
            }
            case 4:{
                fotUrl="cat_5";
                holder.mainLayout.setBackground(ContextCompat.getDrawable(holder.itemView.getContext(),R.drawable.background_categoria));
                break;
            }
        }
        int drawableResourceId=holder.itemView.getContext().getResources().getIdentifier(fotUrl, "drawable",holder.itemView.getContext().getPackageName());

        Glide.with(holder.itemView.getContext())
                .load(drawableResourceId)
                .into(holder.fotoCategoria);
    }

    @Override
    public int getItemCount() {
        return categoriaDomains.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView nomeCategoria;
        ImageView fotoCategoria;
        ConstraintLayout mainLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nomeCategoria=itemView.findViewById(R.id.nomeCategoria);
            fotoCategoria=itemView.findViewById(R.id.fotoCategoria);
            mainLayout=itemView.findViewById(R.id.mainLayout);
        }
    }
}
