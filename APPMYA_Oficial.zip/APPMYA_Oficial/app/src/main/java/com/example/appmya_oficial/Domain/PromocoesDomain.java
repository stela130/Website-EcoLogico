package com.example.appmya_oficial.Domain;

public class PromocoesDomain {
    private String title;
    private String foto;
    private String descricao;
    private Double preco;

    public PromocoesDomain(String title, String foto, String descricao, Double preco) {
        this.title = title;
        this.foto = foto;
        this.descricao = descricao;
        this.preco = preco;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }
}

