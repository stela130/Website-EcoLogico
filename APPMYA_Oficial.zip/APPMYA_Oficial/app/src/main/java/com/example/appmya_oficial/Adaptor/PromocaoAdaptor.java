package com.example.appmya_oficial.Adaptor;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.appmya_oficial.Domain.PromocoesDomain;
import com.example.appmya_oficial.R;

import java.util.ArrayList;

public class PromocaoAdaptor extends RecyclerView.Adapter<PromocaoAdaptor.ViewHolder> {
    ArrayList<PromocoesDomain> promocaoFood;

    public PromocaoAdaptor(ArrayList<PromocoesDomain> promocaoFood) {
        this.promocaoFood = promocaoFood;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate= LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_promocao,parent, false);
        return new ViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.title.setText(promocaoFood.get(position).getTitle());
        holder.preco.setText(String.valueOf(promocaoFood.get(position).getPreco()));

        int drawableResourceId=holder.itemView.getContext().getResources().getIdentifier(promocaoFood.get(position).getFoto(), "drawable",holder.itemView.getContext().getPackageName());

        Glide.with(holder.itemView.getContext())
                .load(drawableResourceId)
                .into(holder.foto);
    }

    @Override
    public int getItemCount() {
        return promocaoFood.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, preco;
        ImageView foto;
        TextView addBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title=itemView.findViewById(R.id.title);
            preco=itemView.findViewById(R.id.preco);
            foto=itemView.findViewById(R.id.foto);
            addBtn=itemView.findViewById(R.id.addBtn);
        }
    }
}
