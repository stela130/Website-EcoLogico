package com.example.appmya_oficial.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.appmya_oficial.DBHelper;
import com.example.appmya_oficial.R;

public class LoginTela extends AppCompatActivity {
    DBHelper dbHelper;
    EditText editeEmail, editeSenha;
    Button btnCadastresse, btnEntrar;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_login);

        dbHelper = new DBHelper(this);
        editeEmail = findViewById(R.id.editeEmail);
        editeSenha = findViewById(R.id.editeSenha);
        btnCadastresse = findViewById(R.id.btnCadastrasse);
        btnEntrar = findViewById(R.id.btnEntrar);

        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean temCadastro = dbHelper.confirmarUsuario(editeEmail.getText().toString(), editeSenha.getText().toString());
                if (temCadastro){
                    Intent intent = new Intent(LoginTela.this, InicialTela.class);
                    startActivity(intent);
                }
                else
                    Toast.makeText(LoginTela.this, "Usuario nao encontrado", Toast.LENGTH_SHORT).show();
            }
        });

        btnCadastresse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(LoginTela.this, CadastroTela.class);
                startActivity(intent);
            }
        });
    }


}
